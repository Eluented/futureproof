const app = require("./app");

const port = 3002;

app.listen(port, () => {
  console.log(`Example app departned from http://localhost:${port}`);
});
